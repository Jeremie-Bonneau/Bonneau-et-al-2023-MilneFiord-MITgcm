README

Originally posted 2023-27-12
Last updated 2023-27-12
 
Milne Fiord ADCP deployment 2011, 2012, 2013

Please see the following publications for more information on the dataset:

Bonneau, J., Laval, B.E., Mueller, D.R., Hamilton, A.K., Forrest, A.L. (2024). : Unsteady Circulation in a Glacial Fjord: a Modelling Study of Milne Fiord. In revision at Journal of Geophysical Research: Oceans. [Paper #2023JC020140].

-----
DATA DESCRIPTION:

This dataset consists of three ADCP deployment in the middle of Milne Fiord (82.6048 N, -80.9172 W)The ADCP was deployed downward-looking in a hole through the ice. 
The data were collected during three (3) field campaigns and files are separated into folders for each campaign, direction and depth using the folder name format "Milne_Fiord_ADCP_DATA_along/acrossfjord_yyyymm" where "yyyymm' is the nominal year and month of the field campaign, along/acrossfjord is the velocity component:
1. Milne_Fiord_ADCP_DATA_alongfjord_2011052. Milne_Fiord_ADCP_DATA_acrossfjord_201105
3. Milne_Fiord_ADCP_DATA_alongfjord_2012074. Milne_Fiord_ADCP_DATA_acrossfjord_201207
5. Milne_Fiord_ADCP_DATA_alongfjord_top_2013076. Milne_Fiord_ADCP_DATA_acrossfjord_top_2013077. Milne_Fiord_ADCP_DATA_alongfjord_bottom_2013078. Milne_Fiord_ADCP_DATA_acrossfjord_bottom_201307

In each file, time is in the y axis and depth bins are on the x axis, i.e. columns are different depths and rows are different time. The first column is time in UTC. NA values associated to bins with bad correlation. Positive values are downfjord (along-fjord) and SW (across-fjord). Top / Bottom is used when two ADCP were used at two different depths.
----
ACKNOWLEDGEMENTS:

This dataset was collected with the support of several individuals and organizations including:

Funding from:
-The Natural Sciences and Engineering Research Council of Canada
-Canada Foundation for Innovation
-ArcticNet Network of Centres of Excellence of Canada 
-Association of Canadian Universities for Northern Studies 
-Garfield Weston Foundation
-The University of British Columbia
-Carleton University

Logistical support was provided by:
-Polar Continental Shelf Program
----
CONTACT:

If this dataset proves useful to your work please let us know! For this and any questions about the dataset, please direct inquiries to:
Dr. Derek Mueller, Carleton University, Ottawa, Canada (derekmueller@cunet.carleton.ca)

